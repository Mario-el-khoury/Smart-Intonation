var annotated_dup =
[
    [ "QWidget", "classQWidget.html", null ],
    [ "Window", "classWindow.html", "classWindow" ]
];