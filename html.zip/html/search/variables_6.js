var searchData=
[
  ['highestfrequency_140',['highestFrequency',['../classWindow.html#ad7decadd4f50eed43d28ec7fe50c5c7f',1,'Window']]],
  ['hlayout_141',['hLayout',['../classWindow.html#a088e83054c444170282461344174f30b',1,'Window']]]
];
