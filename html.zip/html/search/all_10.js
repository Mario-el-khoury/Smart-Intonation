var searchData=
[
  ['testingslot_79',['TestingSlot',['../classWindow.html#a09bbcccbe17f921d3cfa53c082c08814',1,'Window']]],
  ['text_80',['text',['../classWindow.html#aab394c1812db309d61d3188ebd7898bb',1,'Window']]],
  ['text2_81',['text2',['../classWindow.html#ab325d515a8fa04b07eb7a65a0a69ff45',1,'Window']]],
  ['text3_82',['text3',['../classWindow.html#a22a5d30da372daa965fb9ca1dac8e182',1,'Window']]]
];
