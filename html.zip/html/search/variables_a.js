var searchData=
[
  ['n_148',['N',['../fft_8h.html#ab2b6b0c222cd1ce70d6a831f57241e59',1,'fft.h']]],
  ['newest_data_149',['newest_data',['../fft_8h.html#adfcc7f8be460572e335b42dbec648e50',1,'fft.h']]]
];
