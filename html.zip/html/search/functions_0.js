var searchData=
[
  ['add_data_96',['add_data',['../fft_8h.html#ac7d7114419f45bd170212b59a8abd8e2',1,'fft.h']]],
  ['audioexit_97',['audioexit',['../classWindow.html#a2f9b08ea8e0ee9efb926c61ec2c9a5f5',1,'Window']]],
  ['audiorecorderslot_98',['AudioRecorderSlot',['../classWindow.html#a3d808c5e4e49ca42af4a7bad9134cd7b',1,'Window']]]
];
