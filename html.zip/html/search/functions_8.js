var searchData=
[
  ['pauseslot_111',['pauseslot',['../classWindow.html#a0f71e1d5e75b3b36c7529626bb0e7d7d',1,'Window']]],
  ['playslot_112',['playslot',['../classWindow.html#a5e85036588d172ba8557d3120b29ad1e',1,'Window']]],
  ['powr_spectrum_113',['powr_spectrum',['../fft_8h.html#aa79da96886df68fbb168b5d515d093df',1,'fft.h']]]
];
