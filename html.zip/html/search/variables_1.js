var searchData=
[
  ['buffertime_128',['bufferTime',['../classWindow.html#a641304018c42dc8450f206a2fb4c3b37',1,'Window']]]
];
