var searchData=
[
  ['coeffs_129',['coeffs',['../fft_8h.html#aac294c1d0d23893ebbcb31342baa3d3a',1,'fft.h']]],
  ['count_130',['count',['../classWindow.html#a16ca5780696c6c1d21beda483d67b41a',1,'Window']]]
];
