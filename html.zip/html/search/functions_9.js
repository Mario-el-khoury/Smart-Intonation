var searchData=
[
  ['quitapp_114',['quitApp',['../classWindow.html#a35f517c5891c4942e225cc3114ba9a43',1,'Window']]]
];
