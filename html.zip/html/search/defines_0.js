var searchData=
[
  ['do_fftw_177',['DO_FFTW',['../fft_8h.html#a9cb0f176f62a46b7c93e45d94fd565e2',1,'fft.h']]],
  ['do_sdft_178',['DO_SDFT',['../fft_8h.html#ad55f3269940297d4cf8271d7d687a595',1,'fft.h']]]
];
