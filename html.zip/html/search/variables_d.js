var searchData=
[
  ['quitbutton_162',['quitbutton',['../classWindow.html#a3f4d8d0fdddafb0bee3ca61070f52f59',1,'Window']]]
];
