var searchData=
[
  ['videowidget_174',['videoWidget',['../classWindow.html#a2f6c1e9b3fc1cc13b38306706b3a473f',1,'Window']]],
  ['vlayout_175',['vLayout',['../classWindow.html#ab59aad4b199c72d45b5afc6f94160f42',1,'Window']]]
];
