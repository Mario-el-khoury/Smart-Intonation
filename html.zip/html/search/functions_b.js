var searchData=
[
  ['sdft_118',['sdft',['../fft_8h.html#a10e0050543e81b22548d59c5083890c4',1,'fft.h']]],
  ['sipressedslot_119',['SiPressedSlot',['../classWindow.html#a624f226d33e81a84db7d881f05819b1c',1,'Window']]],
  ['sopressedslot_120',['SoPressedSlot',['../classWindow.html#acbb35b80ce11478a5fac25dd43b900a2',1,'Window']]],
  ['stoprecording_121',['stopRecording',['../classWindow.html#a1e1b19159554e5d206cf23418449075e',1,'Window']]]
];
