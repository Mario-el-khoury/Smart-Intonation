var searchData=
[
  ['quitapp_61',['quitApp',['../classWindow.html#a35f517c5891c4942e225cc3114ba9a43',1,'Window']]],
  ['quitbutton_62',['quitbutton',['../classWindow.html#a3f4d8d0fdddafb0bee3ca61070f52f59',1,'Window']]],
  ['qwidget_63',['QWidget',['../classQWidget.html',1,'']]]
];
