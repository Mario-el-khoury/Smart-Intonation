var searchData=
[
  ['samplerate_167',['sampleRate',['../classWindow.html#aabb5287a7bdfda6bc9c5514f2914ea72',1,'Window']]],
  ['sibutton_168',['sibutton',['../classWindow.html#a707fe1699823f4223d8cb321fb8cd5ce',1,'Window']]],
  ['sobutton_169',['sobutton',['../classWindow.html#a1a433a6fc45539c4d743e9f7f9839f36',1,'Window']]],
  ['stopbutton_170',['stopbutton',['../classWindow.html#a5f9811ebf5de9ad1df5b2e65ac5cefe6',1,'Window']]]
];
