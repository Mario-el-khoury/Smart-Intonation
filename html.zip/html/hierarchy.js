var hierarchy =
[
    [ "QWidget", "classQWidget.html", [
      [ "Window", "classWindow.html", null ]
    ] ]
];